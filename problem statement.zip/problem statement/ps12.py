S1 = {"US","IN","NL",}
S2 = {"CA","IN","BE"}
S3=S1.intersection(S2)      #same values
print(S3)
S4=S1.union(S2)             #take single values from both list
print(sorted(S4,reverse=True))