a,b,c,d=input("Enter 4 numbers: ").split()
a=int(a)
b=int(b)
c=int(c)
d=int(d)
if a>b and a>c and a>d:
    if b>c and b>d:
        ans=b
    elif c>b and c>d:
        ans=c
    else:
        ans=d
elif b>a and b>c and b>d:
    if a>c and a>d:
        ans=a
    elif c>a and c>d:
        ans=c
    else:
        ans=d
elif c>a and c>b and c>d:
    if a>b and a>d:
        ans=a
    elif b>a and b>d:
        ans=b
    else:
        ans=d
else:
    if a>b and a>c:
        ans=a
    elif b>a and b>c:
        ans=b
    else:
        ans=c

print("Second largest number is: ",ans)