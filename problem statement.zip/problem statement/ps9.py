def man(l):
    a = l[:3]
    b = l[3:6]
    c = l[6:]

    a=a[::-1]
    b=b[::-1]
    c=c[::-1]

    print(a)
    print(b)
    print(c)

    l1 = a + b + c
    print(l1)

    l2 = [a, b, c]
    print(l2)

L1 = [1, 2, 3, 4, 5, 6, 7, 8, 9]
man(L1)