def dict(headings, *persons):
    result = {}
    for i, heading in enumerate(headings):              #{0:first name,1:last name,2:age} auto indexing
        values = [person[i] for person in persons]
        result[heading] = values                        #{heading:[values]}
    return result

headings = ["first name", "last name", "age"]
person1 = ["Mark", "Taylor", 20]
person2 = ["Emma", "Jones", 30]
x = dict(headings, person1, person2)
print(x)