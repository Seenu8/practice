L1 = [1, 2, 3, 4, 5]
L2 = [11, 22, 33, 44, 55]
a=set(zip(L1, L2))
b=sorted(a)
print(f"Output: S1 = {{{', '.join(map(str, b))}}}")