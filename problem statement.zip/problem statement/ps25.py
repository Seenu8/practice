def shell_sort(arr,n):
    c1,c2,c3=0,0,0
    gap = n // 2
    while gap > 0:
        for i in range(gap, n):
            c1 += 1
            temp = arr[i]
            j = i
            print("j",j,"temp",temp,"gap",gap)                                 #temp is right
            while j >= gap and arr[j - gap] > temp:     #comparing left and right if left is high swap occurs
                c2 += 1
                arr[j] = arr[j - gap]
                j -= gap
                c3 += 1
                print(arr)
            arr[j] = temp
        gap //= 2

    return c1,c2,c3

l=[12, 11, 13, 5, 6]
print("unsorted list:", l)

a,b,c = shell_sort(l,len(l))
print("sorted list:  ",l)
print("\nNumber of iterations:", a)
print("Number of comparisons:", b)
print("Number of swaps:", c)

