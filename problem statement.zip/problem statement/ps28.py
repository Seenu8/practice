import pandas as pd

balance_df = pd.read_csv(f"data\\CustomerAccountBalanceFile.csv", delimiter=';',
                         names=['customer_id', 'current_balance'])
transaction_df = pd.read_csv(f"data\\CustomerAccountTransferFile.csv", delimiter=';',
                             names=['transaction_id', 'customer_id', 'transaction_amount', 'transaction_type', 'transaction_ts'])

# Merge the two dataframes on customer_id
merged_df = pd.merge(balance_df, transaction_df.groupby('customer_id')['transaction_amount'].sum().reset_index(),
                     on='customer_id', how='left')

# Calculate the new balance and create the 'new_balance' column
merged_df['new_balance'] = merged_df['current_balance'] + merged_df['transaction_amount']

# Convert 'new_balance' column to numeric type
merged_df['new_balance'] = pd.to_numeric(merged_df['new_balance'], errors='coerce')

# Create separate dataframes for WARNING, ERROR, and PATRON records
warning_df = merged_df[merged_df['new_balance'] < 100.00]
error_df = merged_df[merged_df['new_balance'] < 0.00]
patron_df = merged_df[merged_df['new_balance'] > 60000.00]

# Write records to WARNING, ERROR, and PATRON files
warning_df[['customer_id', 'new_balance']].to_csv(f"data\\WARNING.csv", index=False, header=False)
error_df[['customer_id', 'new_balance']].to_csv(f"data\\ERROR.csv", index=False, header=False)
patron_df[['customer_id', 'new_balance']].to_csv(f"data\\PATRON.csv", index=False, header=False)

# Sort the final balance file in descending order of updated balance
final_balance_sorted_df = merged_df.sort_values(by='new_balance', ascending=False)

# Write the final balance file
final_balance_sorted_df[['customer_id', 'new_balance']].to_csv(f"data\\FinalBalanceFile.csv", index=False, header=False)

