import pandas as pd
rf=pd.read_csv(f'data\\CustomerIdFile.csv')  #read_csv read and to_csv write
newFile=rf['customer_id'].drop_duplicates()
newFile.to_csv(f'data\\uniqueCustomerId.csv', index=False)  #we don't need index
#newFile is converted to csv and saved in D location