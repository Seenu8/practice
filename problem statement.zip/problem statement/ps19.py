import re
def regax(line, file_b, file_c, file_d):
    words = line.split()
    vw=[]
    for word in words:
        if re.findall("[aeiouAEIOU]",word[0]):
            vw.append(word)

    #vowles in file b
    if vw:
        with open(file_b, 'w') as file:
            file.write('\n'.join(vw) + '\n')

    #number in file c
    nw=[]
    for word in words:
        if re.findall("[0-9]",word[0]):
            nw.append(word)

    if nw:
        with open(file_c, 'w') as file:
            file.write('\n'.join(nw) + '\n')

    # words containing 'a' but not in first and last file d
    sw=[]
    for word in words:
        if 'a' in word and word[0] != 'a' and word[-1] != 'a':
            sw.append(word)

    if sw:
        with open(file_d, 'w') as file:
            file.write('\n'.join(sw) + '\n')

def long(file_path):
    with open(file_path, 'r') as file:
        words = re.findall(r'\b\w+\b', file.read())
        return max(words, key=len, default=None)

a = f'a.txt'
b = f'b.txt'
c = f'c.txt'
d = f'd.txt'

with open(a, 'r') as file:
    for line in file:
        line = line.strip()                 #strip is used for remove unwanted space
        if line and line[0].isupper():
            regax(line, b, c, d)

l = long(a)
print(f"Longest word in file A: {l}")

l = long(b)
print(f"Longest word in file B: {l}")