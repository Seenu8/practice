class CustomQueue:
    def __init__(self):
        self.queue = []

    def put(self, item):
        self.queue.append(item)

    def get(self):
        if not self.is_empty():
            return self.queue.pop(0)
        else:
            return "Queue is empty"

    def get_size(self):
        return len(self.queue)

    def is_empty(self):
        return len(self.queue) == 0

    def truncate(self):
        self.queue = []

q = CustomQueue()

q.put(1)
q.put(2)
q.put(3)

print("Get:", q.get())
print("Size:", q.get_size())
print("Is Empty:", q.is_empty())
q.truncate()
print("Is Empty after truncation:", q.is_empty())