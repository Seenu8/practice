def quick_sort(arr):            #comparing first and pivot
    c1=c2=c3=0
    
    def partition(low, high):
        nonlocal c1, c2, c3
        pivot = arr[high]
        i = low - 1

        for j in range(low, high):
            c1 += 1
            c2 += 1
            if arr[j] < pivot:
                i += 1
                arr[i], arr[j] = arr[j], arr[i]
                c3 += 1

        arr[i + 1], arr[high] = arr[high], arr[i + 1]
        c3 += 1
        return i + 1

    def sort_list(low, high):
        nonlocal c1, c2, c3
        if low < high:
            pi = partition(low, high)
            sort_list(low, pi - 1)
            sort_list(pi + 1, high)

    sort_list(0, len(arr) - 1)
    return c1, c2, c3


l=[12, 11, 13, 5, 6]
print("unsorted list:", l)

a,b,c = quick_sort(l)
print("sorted list:  ",l)
print("\nNumber of iterations:", a)
print("Number of comparisons:", b)
print("Number of swaps:", c)
