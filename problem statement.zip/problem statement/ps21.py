class CustomStack:
    def __init__(self):
        self.stack = []

    def push(self, item):
        self.stack.append(item)

    def pop(self):
        if not self.is_empty():
            return self.stack.pop()
        else:
            raise IndexError("Stack is empty")

    def get_size(self):
        return len(self.stack)

    def is_empty(self):
        return len(self.stack) == 0

    def truncate(self):
        self.stack = []

s = CustomStack()

s.push(1)
s.push(2)
s.push(3)

print("Pop:", s.pop())
print("Size:", s.get_size())
print("Is Empty:", s.is_empty())
s.truncate()
print("Is Empty after truncation:", s.is_empty())