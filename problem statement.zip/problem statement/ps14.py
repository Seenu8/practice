def charCount(path):
    s = {}                                     #s is dict so s has key and value

    with open(path, 'r') as file:
        line = file.read()
        for char in line:
            s[char] = s.get(char, 0) + 1       #s[char]  for char(key): s[char](count)(value)
                                               #print(char,s[char],end=" ") key and value

    print("Characters and their counts in alphabetical order:")
    for char in sorted(s):
        print(f"{char}: {s[char]}",end=" ")

    print("\nCharacters and their counts in descending order of counts:")
    for char, count in sorted(s.items(), key=lambda x: x[1], reverse=True): #x[0] is key and x[1] is value
        print(f"{char}: {count}",end=" ")                                   #it will sort based on count

charCount(f'python.txt')
