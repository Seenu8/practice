def nd(n):
    a=[]
    i=0
    while i < n:
        c = int(input("Enter a number for list: "))
        if c not in a:
            a.append(c)
            i += 1
        else:
            print("The number is already in list")
    return a

l1=int(input("enter a number: "))
l2=int(input("enter a number: "))
a=nd(l1)
b=nd(l2)

c=list(set(a) & set(b))
#c=[i for i in a if i in b]
d=list(set(a) ^ set(b))
#d=[i for i in a if i not in b]
print("list C:",c)
print("list D:",d)
print("acending order c:",sorted(c))
print("descending order d:",sorted(d,reverse=True))