numbers=[1,2,3,4,5,1,2,3,4,5,1,2,3,1,2,1,2,3,4,5]
numbers.sort()
print('first:',numbers[0],'and last:',numbers[-1])
if 2 in numbers:
    print("PRESENT")
else:
    print("NOT PRESENT")
print('Count:',numbers.count(4))