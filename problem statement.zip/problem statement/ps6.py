def fml(s1,s2):
    c = ""
    c += s1[0]+s2[0]
    c += s1[len(s1) // 2]+s2[len(s2) // 2]
    c += s1[-1]+s2[-1]
    return c

s1=input("Enter a String:")
s2=input("Enter a String:")
print(fml(s1,s2))