import random
b=random.randint(1,10)
while True:
    try:
        a = int(input("Enter a number:"))
        if a==b:
            print("YOUR GUESS IS CORRECT")
            break
        else:
            print("YOUR GUESS IS WRONG")
        ex=input("Enter exit to end the funtion or press enter to continue: ")
        if ex=="exit":
            break
    except:
        print("YOU ENTERED AN INVALID NUMBER")
