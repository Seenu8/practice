def fun(*args):
    b=sum(args)
    c=round(b/len(args),2)
    d=max(args)
    e=min(args)
    return b,c,d,e

a=[int(i) for i in input("Enter a numbers: ").split()]
res=fun(*a)
print("sum is:",res[0])
print("avg is:",res[1])
print("max is:",res[2])
print("min is:",res[3])
