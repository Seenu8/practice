def insertion_sort(arr):
    c1=c2=c3=0
    for i in range(1, len(arr)):
        temp = arr[i]                   #temp=11,13,5
        j = i - 1                       #j 0 1 2
        c1 += 1
        while j >= 0 and temp < arr[j]:     #temp=11,13,5 arr[0]=12,arr[1]=12 arr[2]=13 arr[1]=12 arr[0]=11
            c2 += 1
            arr[j + 1] = arr[j]             #arr[1]=12,arr[3]=13,arr[2]=12,arr[1]=11
            j -= 1                          #j=-1,1,0,-1
            c3 += 1
        arr[j + 1] = temp               #arr[-1+1] arr[0]=11,13

        #arr=5,11,12,13,6

    return c1,c2,c3

l=[12, 11, 13, 5, 6]
print("unsorted list:", l)

a,b,c = insertion_sort(l)
print("sorted list:  ",l)
print("\nNumber of iterations:", a)
print("Number of comparisons:", b)
print("Number of swaps:", c)