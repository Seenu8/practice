class BankAccount:
    def __init__(self, user, balance=0):
        self.user = user
        self.balance = balance

    def deposit(self, amount):
        self.balance += amount
        print(self.balance)

    def withdraw(self, amount):
        if self.balance>=amount:
            self.balance -= amount
            print(self.balance)
        else:
            print(f"Insufficient balance so,check balance")

    def check_bal(self):
        print(self.balance)


sam = BankAccount("sam")
rio = BankAccount("rio")

sam.deposit(100)
rio.deposit(200)
sam.withdraw(20)
#rio.withdraw(201)
#rio.check_bal()
rio.withdraw(200)