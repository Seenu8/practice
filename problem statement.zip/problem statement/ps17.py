"""
CustomerAccountBalanceFile has customer id and balance
calculate intrest rate 4% >=100 
<=100 balance no intrest 
if intrest calculated       -> InterestAmount.csv
if intrest not calculated   -> DefaultCustomerFile.csv
"""

import csv

class BankAccount:
    def __init__(self, customer_id, current_balance):
        self.customer_id = customer_id
        self.current_balance = current_balance

    def deposit(self, amount):
        self.current_balance += amount

    def withdraw(self, amount):
        if amount <= self.current_balance:
            self.current_balance -= amount
        else:
            print(f"Insufficient funds for customer {self.customer_id}.")

    def calculate_interest(self, interest_rate=0.04):
        if self.current_balance >= 100.00:
            interest_amount = self.current_balance * interest_rate
            return interest_amount
        else:
            return None

def process_accounts(file1, file2, file3):
    accounts = []


    with open(file1, 'r', newline='') as file:
        reader = csv.reader(file, delimiter=';')
        next(reader)

        for row in reader:
            customer_id, current_balance = row
            account = BankAccount(customer_id, float(current_balance))
            accounts.append(account)


    with open(file2, 'w', newline='') as interest_file, \
         open(file3, 'w', newline='') as default_file:

        interest_writer = csv.writer(interest_file)
        default_writer = csv.writer(default_file)

        interest_writer.writerow(['Customer ID', 'Interest Amount'])
        default_writer.writerow(['Customer ID', 'Current Balance'])

        for account in accounts:
            interest_amount = account.calculate_interest()
            if interest_amount is not None:
                interest_writer.writerow([account.customer_id, interest_amount])
            else:
                default_writer.writerow([account.customer_id, account.current_balance])


process_accounts(f'data\\CustomerAccountBalanceFile.csv',
                 f'data\\InterestAmount.csv',
                 f'data\\DefaultCustomerFile.csv')