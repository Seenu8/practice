from collections import Counter
def manipulate_str(g):
    a = g.split()

    # 1
    s = " ".join(a[1:])
    c = len(a[0])
    d = g[1:c - 1] + g[0] + g[c - 1] + "" + s
    f = ""
    for i in d:
        if i.isdigit() or "." in i or i in ['!', '#']:
            continue
        else:
            f += i
    print(f)

    # 2
    b = " ".join(a[::-1])
    print(b)

    #3
    b = b.split()
    c = []
    for i in b:
        if i.isdigit() or "." in i:
            c.append(i)
        else:
            c.append(i[::-1])
    s = " ".join(c)
    print(s)

    # 4
    ct = 0
    for i in b:
        if i.isdigit() or "." in i:
            ct += 1
    print("count of numbers:", ct)

    # 5
    ct = 0
    for i in g:
        if i in ["!", "#", "$", "&"]:
            ct += 1
    print("count of special character:", ct)

    # 6
    di = dict(Counter(g))
    print(di)

    # 7
    l = []
    for i in b:
        if "." in i:
            l.append(float(i))
        elif (i.isdigit()):
            l.append(int(i))

    st = "sum:" + str(sum(l)) + " avg:" + str((sum(l)) / len(l)) + " max:" + str(max(l)) + " min:" + str(min(l))
    print(st)

    # 8
    for i in g:
        if i not in ["!", "#", "$", "&"]:
            print(i, end="")
    print()

    # 9
    li = list(sorted(l))
    print(*li)

g="PythoN 3.8 is great! 40"
manipulate_str(g)
