def unique(l1):
    u1 = set(l1)
    return len(u1) == len(l1)

l1 = [1, 2, 3, 4, 5]
l2 = [1, 2, 3, 4, 1]
r1 = unique(l1)
r2=unique(l2)
print(r1)
print(r2)