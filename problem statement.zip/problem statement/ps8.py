l=['abc','xyz','aba','1221']
ct=0
for i in l:
    if len(i)>2:
        if i[0]==i[-1]:
            ct+=1
print(ct)