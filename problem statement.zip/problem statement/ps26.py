def merge_sort(arr):
    c1=c2=c3=0

    if len(arr) > 1:
        mid = len(arr) // 2
        la = arr[:mid]
        ra = arr[mid:]

        #Recursive 
        il, cl, sl = merge_sort(la)
        ir, cr, sr = merge_sort(ra)

        c1 += il + ir
        c2 += cl + cr
        c3 += sl + sr

        i = j = k = 0

        #Merge
        while i < len(la) and j < len(ra):
            c1 += 1
            c2 += 1
            if la[i] < ra[j]:
                arr[k] = la[i]
                i += 1
            else:
                arr[k] = ra[j]
                j += 1
                c3 += 1
            k += 1

        while i < len(la):
            arr[k] = la[i]
            i += 1
            k += 1

        while j < len(ra):
            arr[k] = ra[j]
            j += 1
            k += 1

    return c1, c2, c3


l=[12, 11, 13, 5, 6]
print("unsorted list:", l)

a,b,c = merge_sort(l)
print("sorted list:  ",l)
print("\nNumber of iterations:", a)
print("Number of comparisons:", b)
print("Number of swaps:", c)
